//package com.example.demo;
//
//import org.springframework.boot.CommandLineRunner;
//import org.springframework.boot.autoconfigure.SpringBootApplication;
//
//@SpringBootApplication
//public class MongodbappApplication implements CommandLineRunner {
//    @Override
//    public void run(String... args) {
//
//
//
//    }
//}
