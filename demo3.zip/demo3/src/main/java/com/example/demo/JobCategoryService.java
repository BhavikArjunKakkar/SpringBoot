package com.example.demo;

import org.springframework.stereotype.Service;

@Service
public interface JobCategoryService extends GenericService<JobCategory> {



}
